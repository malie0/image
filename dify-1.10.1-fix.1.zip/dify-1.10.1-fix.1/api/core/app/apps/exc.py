class GenerateTaskStoppedError(Exception):
    pass
