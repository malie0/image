from configs.observability.otel.otel_config import OTelConfig


class ObservabilityConfig(OTelConfig):
    """
    Observability configuration settings
    """

    pass
