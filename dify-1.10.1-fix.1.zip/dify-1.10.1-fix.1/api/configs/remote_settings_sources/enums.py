from enum import StrEnum


class RemoteSettingsSourceName(StrEnum):
    APOLLO = "apollo"
    NACOS = "nacos"
